

#include "Tests.h"

// all login test are here 


/***********************************************************************************
* Test ID                : TestCase 3
* Description            : Admin login with correct token
* Pre-requisits          : Admin enters the valid token
* Test inputs            :
*                          Token                        -> 10203040
* Test Expected output   : Admin access granted
* Reason                 : Token matches value in Sec.h
*************************************************************************************/
static void Test_Admin_Login_Correct_Token(void)
{
	int token = 10203040;
	CU_ASSERT_EQUAL(token, SECRET_ADMIN_TOKEN);
}

/************************************************************************************
* Test ID                : TestCase 4
* Description            : Admin login fails after 3 wrong token attempts
* Pre-requisits          : Admin enters 3 wrong tokens
* Test inputs            : Tokens -> 123, 456, 789
* Test Expected output   : Admin access denied
* Reason                 : All attempts failed to match secret token
*************************************************************************************/
static void Test_Admin_Login_Failure_Token(void)
{
	int attempts = 3;
	int wrong_tokens[3] = { 123, 456, 789 };
	int success = 0;

	for (int i = 0; i < attempts; i++) {
		if (wrong_tokens[i] == SECRET_ADMIN_TOKEN) {
			success = 1;
			break;
		}
	}

	CU_ASSERT_EQUAL(success, 0);
}

/************************************************************************************
* Test ID                : TestCase 5
* Description            : Normal user login success
* Pre-requisits          : User exists with correct credentials
* Test inputs            : Username -> AdminUser1, Password -> Edges123
* Test Expected output   : Login should be successful
* Reason                 : Credentials are correct
*************************************************************************************/
static void Test_User_Login_Success(void)
{
	int id;
	unsigned char result = Verify_User("AdminUser1", "Edges123", &id);
	CU_ASSERT_EQUAL(result, Login_Successful);
	CU_ASSERT_NOT_EQUAL(id, -1);
}


/************************************************************************************
* Test ID                : TestCase 6
* Description            : Normal user login fails with wrong password
* Pre-requisits          : User exists but enters wrong password
* Test inputs            : Username -> AdminUser1, Password -> WrongPass
* Test Expected output   : Login should fail
* Reason                 : Password is incorrect
*************************************************************************************/
static void Test_User_Login_Wrong_Password(void)
{
	int id;
	unsigned char result = Verify_User("AdminUser1", "WrongPass", &id);
	CU_ASSERT_EQUAL(result, Password_incorrect);
	CU_ASSERT_EQUAL(id, -1);
}

/************************************************************************************
* Test ID                : TestCase 7
* Description            : Normal user login fails with wrong username
* Pre-requisits          : Non-existent username used
* Test inputs            : Username -> NotAUser, Password -> AnyPass
* Test Expected output   : Login should fail
* Reason                 : Username is not in DB
*************************************************************************************/
static void Test_User_Login_Wrong_Username(void)
{
	int id;
	unsigned char result = Verify_User("NotAUser", "AnyPass", &id);
	CU_ASSERT_EQUAL(result, UserName_NotFound);
	CU_ASSERT_EQUAL(id, -1);
}

/************************************************************************************
* Test ID                : TestCase 8
* Description            : Simulate the deletion of a user after 3 failed login attempts
* Pre-requisits          : A user with correct credentials exists in DB
* Test inputs            :
*                          Username -> ToDeleteUser
*                          Password -> WrongPass (entered 3 times)
* Test Expected output   : The user should be deleted from DB after 3 wrong attempts
* Reason                 : The system deletes user on 3 wrong login trials
*************************************************************************************/
static void Test_User_Login_Delete_After_3_Wrong_Attempts(void)
{
	struct User_Input_Type temp_user = {
		{ -1, "ToDelete", 30, 1, 1, 1990, Male, Student },
		{ { "ToDeleteUser", "ToDeletePass" }, "ToDeletePass" }
	};

	// Step 1: Add the user
	unsigned char added = Add_Account(&temp_user);
	CU_ASSERT_EQUAL(added, TRUE);

	// Step 2: Try to login with wrong password 3 times
	int id;
	unsigned char result = 0;
	for (int i = 0; i < 3; i++) {
		result = Verify_User("ToDeleteUser", "WrongPass", &id);
	}

	CU_ASSERT_EQUAL(result, Password_incorrect);

	// Step 3: Simulate auto-deletion as done in BackEnd
	unsigned char deleted = DBM_Delete_User(current_user_test - 1);
	CU_ASSERT_EQUAL(deleted, TRUE);
}


void Login_Test_Runner(void) {

	/* initialize the Registry */
	CU_initialize_registry();

	/* Adding Test Suite to the Registry */

	CU_pSuite suite_login = CU_add_suite("Login Functionality", NULL, NULL);

	/* Adding Test Cases to the Test Suite*/
	CU_add_test(suite_login, "Admin Login with Correct Token", Test_Admin_Login_Correct_Token);
	CU_add_test(suite_login, "Admin Login Fails After 3 Wrong Tokens", Test_Admin_Login_Failure_Token);
	CU_add_test(suite_login, "User Login Success", Test_User_Login_Success);
	CU_add_test(suite_login, "User Login Wrong Password", Test_User_Login_Wrong_Password);
	CU_add_test(suite_login, "User Login Wrong Username", Test_User_Login_Wrong_Username);
	CU_add_test(suite_login, "User Deleted After 3 Wrong Passwords", Test_User_Login_Delete_After_3_Wrong_Attempts);
	
	/* Running the Test Suite through Basic Console */
	CU_basic_set_mode(CU_BRM_VERBOSE);
	CU_basic_run_tests();

	/* Running the Test Suite through Console interactive */
	 // CU_console_run_tests();

	/* Clear the registry after test finished */
	CU_cleanup_registry();
} 