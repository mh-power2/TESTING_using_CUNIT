#include "Tests.h"

// Local variables to simulate interactive password change
static char Current_Password[32];
static struct LoginCredentials_Form_Type ChangePasswordRequests;

/************************************************************************************
* Test ID                : TestCase 9
* Description            : Successful password change
* Pre-requisits          : AdminUser1 exists and uses correct current password
* Test inputs            :
*                          Username         -> AdminUser1
*                          Old Password     -> Edges123
*                          New Password     -> NewPassword1
*                          Confirm Password -> NewPassword1
* Test Expected output   : Password updated in DB
* Reason                 : Correct old password and matching new passwords
*************************************************************************************/
static void Test_Password_Change_Success(void)
{
    int id;
    Verify_User("AdminUser1", "Edges123", &id);

    strcpy(Current_Password, "Edges123");
    strcpy(ChangePasswordRequests.LoginCredentials.Password, "NewPassword1");
    strcpy(ChangePasswordRequests.Password_Recheck, "NewPassword1");

    if (strcmp(Current_Password, DB_LoginCredentials[id].Password) == 0 &&
        strcmp(ChangePasswordRequests.LoginCredentials.Password, ChangePasswordRequests.Password_Recheck) == 0)
    {
        strcpy(DB_LoginCredentials[id].Password, ChangePasswordRequests.LoginCredentials.Password);
    }

    CU_ASSERT_STRING_EQUAL(DB_LoginCredentials[id].Password, "NewPassword1");
}

/************************************************************************************
* Test ID                : TestCase 10
* Description            : Password change fails due to wrong current password
* Pre-requisits          : AdminUser1 exists but enters wrong current password
* Test inputs            :
*                          Old Password     -> WrongOldPass
*                          New Password     -> NewTry123
*                          Confirm Password -> NewTry123
* Test Expected output   : Password should NOT be updated
* Reason                 : Current password is incorrect
*************************************************************************************/
static void Test_Password_Change_Wrong_Old(void)
{
    int id;
    Verify_User("AdminUser1", "NewPassword1", &id);

    strcpy(Current_Password, "WrongOldPass");
    strcpy(ChangePasswordRequests.LoginCredentials.Password, "NewTry123");
    strcpy(ChangePasswordRequests.Password_Recheck, "NewTry123");

    if (strcmp(Current_Password, DB_LoginCredentials[id].Password) == 0 &&
        strcmp(ChangePasswordRequests.LoginCredentials.Password, ChangePasswordRequests.Password_Recheck) == 0)
    {
        strcpy(DB_LoginCredentials[id].Password, ChangePasswordRequests.LoginCredentials.Password);
    }

    CU_ASSERT_NOT_EQUAL(strcmp(DB_LoginCredentials[id].Password, "NewTry123"), 0);
}

/************************************************************************************
* Test ID                : TestCase 11
* Description            : Password change fails due to mismatch between new and confirm password
* Pre-requisits          : AdminUser1 enters correct current password but mismatches confirmation
* Test inputs            :
*                          Old Password     -> NewPassword1
*                          New Password     -> NewPass2025
*                          Confirm Password -> WrongConfirm
* Test Expected output   : Password should NOT be updated
* Reason                 : New and confirm password do not match
*************************************************************************************/
static void Test_Password_Change_Mismatch(void)
{
    int id;
    Verify_User("AdminUser1", "NewPassword1", &id);

    strcpy(Current_Password, "NewPassword1");
    strcpy(ChangePasswordRequests.LoginCredentials.Password, "NewPass2025");
    strcpy(ChangePasswordRequests.Password_Recheck, "WrongConfirm");

    if (strcmp(Current_Password, DB_LoginCredentials[id].Password) == 0 &&
        strcmp(ChangePasswordRequests.LoginCredentials.Password, ChangePasswordRequests.Password_Recheck) == 0)
    {
        strcpy(DB_LoginCredentials[id].Password, ChangePasswordRequests.LoginCredentials.Password);
    }

    CU_ASSERT_NOT_EQUAL(strcmp(DB_LoginCredentials[id].Password, "NewPass2025"), 0);
}

/************************************************************************************
* Test ID                : TestCase 12
* Description            : Password change fails due to weak password (length < 8)
* Pre-requisits          : AdminUser1 enters a short new password
* Test inputs            :
*                          Old Password     -> NewPassword1
*                          New Password     -> weak
*                          Confirm Password -> weak
* Test Expected output   : Password should NOT be updated
* Reason                 : New password is too short
*************************************************************************************/
static void Test_Password_Change_Weak(void)
{
    int id;
    Verify_User("AdminUser1", "NewPassword1", &id);

    strcpy(Current_Password, "NewPassword1");
    strcpy(ChangePasswordRequests.LoginCredentials.Password, "weak");
    strcpy(ChangePasswordRequests.Password_Recheck, "weak");

    int valid_length = strlen(ChangePasswordRequests.LoginCredentials.Password) >= 8;

    if (strcmp(Current_Password, DB_LoginCredentials[id].Password) == 0 &&
        strcmp(ChangePasswordRequests.LoginCredentials.Password, ChangePasswordRequests.Password_Recheck) == 0 &&
        valid_length)
    {
        strcpy(DB_LoginCredentials[id].Password, ChangePasswordRequests.LoginCredentials.Password);
    }

    CU_ASSERT_NOT_EQUAL(strcmp(DB_LoginCredentials[id].Password, "weak"), 0);
}

/************************************************************************************
* Test ID                : PasswordManager_TestRunner
* Description            : Adds password-related tests to the test registry
*************************************************************************************/
void PasswordManager_TestRunner(void)
{
    /* initialize the Registry */
    CU_initialize_registry();

    CU_pSuite suite_password = CU_add_suite("Password Management", NULL, NULL);

    CU_add_test(suite_password, "Password Change Success", Test_Password_Change_Success);
    CU_add_test(suite_password, "Wrong Old Password", Test_Password_Change_Wrong_Old);
    CU_add_test(suite_password, "New Password Mismatch", Test_Password_Change_Mismatch);
    CU_add_test(suite_password, "Weak New Password Rejected", Test_Password_Change_Weak);

    /* Running the Test Suite through Basic Console */
    CU_basic_set_mode(CU_BRM_VERBOSE);
    CU_basic_run_tests();

    /* Running the Test Suite through Console interactive */
     // CU_console_run_tests();

    /* Clear the registry after test finished */
    CU_cleanup_registry();
}
