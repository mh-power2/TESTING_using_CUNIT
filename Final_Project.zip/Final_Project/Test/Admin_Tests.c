
#include "Tests.h"

static struct User_Input_Type NewUser = {
    {
        -1, "Omar", 30, 15, 8, 1994, Male, Graduate
    },
    {
        {"TestUser_Omar", "OmarPass123"},
        "OmarPass123"
    }
};

static int CreatedUserID;

/************************************************************************************
* Test ID                : TestCase 19
* Description            : Admin adds a new normal user
* Pre-requisits          : Admin mode active, form filled correctly
* Test inputs            : Name, Age, DOB, Education, Gender, Username, Password
* Test Expected output   : DB should store user and credentials
* Reason                 : Simulate admin adding a user (not an admin)
*************************************************************************************/
static void Test_Admin_Adds_New_User(void)
{
    unsigned char RET = Add_Account(&NewUser);
    CU_ASSERT_EQUAL(RET, TRUE);
    CreatedUserID = current_user_test - 1;
    CU_ASSERT_STRING_EQUAL(DB_info[CreatedUserID].name, NewUser.PersonalInfo_Form.name);
    CU_ASSERT_STRING_EQUAL(DB_LoginCredentials[CreatedUserID].User_Name, NewUser.LoginCredentials_Form.LoginCredentials.User_Name);
}

/************************************************************************************
* Test ID                : TestCase 20
* Description            : Admin deletes an existing user
* Pre-requisits          : A user is created and valid
* Test inputs            : Valid user ID from previous test
* Test Expected output   : User should be removed from DB and credentials cleared
* Reason                 : Ensure Admin can delete a user successfully
*************************************************************************************/
static void Test_Admin_Deletes_Existing_User(void)
{
    unsigned char RET = Delete_Account(CreatedUserID);
    CU_ASSERT_EQUAL(RET, TRUE);
    CU_ASSERT_STRING_NOT_EQUAL(DB_info[CreatedUserID].name, NewUser.PersonalInfo_Form.name);
}

/************************************************************************************
* Test ID                : TestCase 21
* Description            : Admin attempts to delete non-existent user
* Pre-requisits          : Invalid user ID used (e.g. 100)
* Test inputs            : Invalid user ID
* Test Expected output   : Deletion should fail and return FALSE
* Reason                 : Boundary test for invalid deletion
*************************************************************************************/
static void Test_Admin_Deletes_Invalid_User(void)
{
    unsigned char RET = Delete_Account(100);
    CU_ASSERT_EQUAL(RET, FALSE);
}

/************************************************************************************
* Test ID                : TestCase 22
* Description            : Admin prints all users
* Pre-requisits          : Database contains initial users
* Test inputs            : None (output-only)
* Test Expected output   : DBM_PrintUsers() executes without crash
* Reason                 : Ensure print all users executes in Admin mode
*************************************************************************************/
static void Test_Admin_Print_All_Users(void)
{
    DBM_PrintUsers();  // Visually confirm from output, check for crash-free execution
    CU_PASS("DBM_PrintUsers executed");
}

/************************************************************************************
* Test ID                : TestCase 23
* Description            : Admin prints one user with valid ID
* Pre-requisits          : User ID 0 exists (Ahmed from initDB)
* Test inputs            : user_id = 0
* Test Expected output   : DBM_PrintUserData_Admin returns TRUE and prints
* Reason                 : Check valid user retrieval
*************************************************************************************/
static void Test_Admin_Print_One_Valid_User(void)
{
    unsigned char RET = DBM_PrintUserData_Admin(0);
    CU_ASSERT_EQUAL(RET, TRUE);
}

/************************************************************************************
* Test ID                : TestCase 24
* Description            : Admin prints user with invalid ID
* Pre-requisits          : Use a user ID outside current DB
* Test inputs            : user_id = 150
* Test Expected output   : DBM_PrintUserData_Admin returns FALSE
* Reason                 : Ensure function handles invalid input
*************************************************************************************/
static void Test_Admin_Print_Invalid_User(void)
{
    unsigned char RET = DBM_PrintUserData_Admin(150);
    CU_ASSERT_EQUAL(RET, FALSE);
}

void Admin_TestRunner(void)
{
    /* initialize the Registry */
    CU_initialize_registry();

    CU_pSuite suite_admin = CU_add_suite("Admin Feature Tests", NULL, NULL);

    CU_add_test(suite_admin, "Admin Adds New User", Test_Admin_Adds_New_User);
    CU_add_test(suite_admin, "Admin Deletes Existing User", Test_Admin_Deletes_Existing_User);
    CU_add_test(suite_admin, "Admin Deletes Invalid User", Test_Admin_Deletes_Invalid_User);
    CU_add_test(suite_admin, "Admin Print All Users", Test_Admin_Print_All_Users);
    CU_add_test(suite_admin, "Admin Print One Valid User", Test_Admin_Print_One_Valid_User);
    CU_add_test(suite_admin, "Admin Print Invalid User", Test_Admin_Print_Invalid_User);
    /* Running the Test Suite through Basic Console */
    CU_basic_set_mode(CU_BRM_VERBOSE);
    CU_basic_run_tests();
    /* Running the Test Suite through Console interactive */
     // CU_console_run_tests();

    /* Clear the registry after test finished */
    CU_cleanup_registry();
}
