#include "Tests.h"

//extern unsigned char Enrollments[MAX_USERS][MAX_COURSES];
extern struct Course ListofCourse[MAX_COURSES];

static int Session_User_id;
static unsigned char RET;

/************************************************************************************
* Test ID                : TestCase 13
* Description            : Reserve a valid course successfully
* Pre-requisits          : AdminUser2 is logged in and course is available
* Test inputs            : Username -> AdminUser2, Password -> Edges123456, Course ID -> 1
* Test Expected output   : User should be enrolled in course ID 1
* Reason                 : Valid credentials and valid course ID
*************************************************************************************/
static void Test_Reserve_Valid_Course(void)
{
    Verify_User("AdminUser2", "Edges123456", &Session_User_id);
    RET = AddStudentToCourse(1, Session_User_id);
    CU_ASSERT_EQUAL(RET, Enrolled);
    CU_ASSERT_TRUE(Enrollments[Session_User_id][0] == TRUE);
}

/************************************************************************************
* Test ID                : TestCase 14
* Description            : Prevent enrolling in the same course twice
* Pre-requisits          : AdminUser2 already enrolled in course ID 1
* Test inputs            : Course ID -> 1
* Test Expected output   : Enrollment should fail with AlreadyEnrolled
* Reason                 : Duplicate enrollment attempt
*************************************************************************************/
static void Test_Duplicate_Course_Reservation(void)
{
    RET = AddStudentToCourse(1, Session_User_id);
    CU_ASSERT_EQUAL(RET, AlreadyEnrolled);
}

/************************************************************************************
* Test ID                : TestCase 15
* Description            : Prevent enrolling in out-of-range course ID
* Pre-requisits          : User is logged in
* Test inputs            : Course ID -> 99 (invalid)
* Test Expected output   : Enrollment should fail or not occur
* Reason                 : Course ID is invalid or outside of range
*************************************************************************************/
static void Test_Invalid_Course_ID(void)
{
    RET = AddStudentToCourse(99, Session_User_id);
    CU_ASSERT_NOT_EQUAL(RET, Enrolled);
}

/************************************************************************************
* Test ID                : TestCase 16
* Description            : Show enrolled courses for user
* Pre-requisits          : User has already enrolled in at least one course
* Test inputs            : User ID -> AdminUser2 ID
* Test Expected output   : Course list should include ID 1
* Reason                 : Confirmation that enrollment is trackable
*************************************************************************************/
static void Test_Show_Enrolled_Courses(void)
{
    int found = 0;
    for (int i = 0; i < MAX_COURSES; ++i)
    {
        if (Enrollments[Session_User_id][i] == TRUE)
        {
            found = 1;
            break;
        }
    }
    CU_ASSERT_TRUE(found);
}

/************************************************************************************
* Test ID                : TestCase 17
* Description            : Ensure deleting a user removes their course reservations
* Pre-requisits          : User is enrolled in courses and then deleted
* Test inputs            : Delete AdminUser2 after enrollment
* Test Expected output   : Enrollments should be cleared for the deleted user
* Reason                 : Data consistency after user deletion
*************************************************************************************/
static void Test_User_Deletion_Removes_Course_Enrollment(void)
{
    DBM_Delete_User(Session_User_id);
    int still_enrolled = 0;

    for (int i = 0; i < MAX_COURSES; ++i)
    {
        if (Enrollments[Session_User_id][i] == TRUE)
        {
            still_enrolled = 1;
            break;
        }
    }
    CU_ASSERT_FALSE(still_enrolled);
}

/************************************************************************************
* Test ID                : CourseReservation_TestRunner
* Description            : Runs all course reservation-related test cases
*************************************************************************************/
void CourseReservation_TestRunner(void)
{
    /* initialize the Registry */
    CU_initialize_registry();

    CU_pSuite suite_course = CU_add_suite("Course Reservation Tests", NULL, NULL);

    CU_add_test(suite_course, "Reserve Valid Course", Test_Reserve_Valid_Course);
    CU_add_test(suite_course, "Duplicate Course Enrollment", Test_Duplicate_Course_Reservation);
    CU_add_test(suite_course, "Invalid Course ID", Test_Invalid_Course_ID);
    CU_add_test(suite_course, "Show Enrolled Courses", Test_Show_Enrolled_Courses);
    CU_add_test(suite_course, "User Deletion Removes Reservation", Test_User_Deletion_Removes_Course_Enrollment);

    /* Running the Test Suite through Basic Console */
    CU_basic_set_mode(CU_BRM_VERBOSE);
    CU_basic_run_tests();

    /* Running the Test Suite through Console interactive */
     // CU_console_run_tests();

    /* Clear the registry after test finished */
    CU_cleanup_registry();
}