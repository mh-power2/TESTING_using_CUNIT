#include "Tests.h" 

// ==========================================================
// Corrected Test Data Structures using Designated Initializers
// ==========================================================

/* Test Data for a VALID Sign Up */
static struct User_Input_Type Test1_User_Valid = {
    .PersonalInfo_Form = {
        .id = -1, // Indicate unassigned ID
        .name = "Ahmed Tarek",
        .Age = 26,
        .DOB_day = 23,
        .DOB_month = 10,
        .DOB_year = 1998,
        .gender = Male,
        .educational_status = Masters_Student
    },
    .LoginCredentials_Form = {
        .LoginCredentials = {
            .User_Name = "EdgesAcademyUser",
            .Password = "EdgesPass123"
        },
        .Password_Recheck = "EdgesPass123"
    }
};

/* Test Data for Mismatched Passwords */
static struct User_Input_Type Test2_User_MismatchPass = {
    .PersonalInfo_Form = {
        .id = -1,
        .name = "Rania Hesham",
        .Age = 54,
        .DOB_day = 31,
        .DOB_month = 12,
        .DOB_year = 1970,
        .gender = Female,
        .educational_status = PHD_Holder
    },
    .LoginCredentials_Form = {
        .LoginCredentials = {
            .User_Name = "RaniaUser2024",
            .Password = "ValidPassword1" // Valid length
        },
        .Password_Recheck = "DifferentPass2" // Mismatched, valid length
    }
};

// --- Name Length Tests ---
static struct User_Input_Type Test_Name_Len2 = { .PersonalInfo_Form = {.name = "Ab", .Age = 25, .DOB_day = 1, .DOB_month = 1, .DOB_year = 2000, .gender = Male, .educational_status = Student}, .LoginCredentials_Form = {.LoginCredentials = {.User_Name = "UserNL2", .Password = "GoodPass123"}, .Password_Recheck = "GoodPass123"} };
static struct User_Input_Type Test_Name_Len3 = { .PersonalInfo_Form = {.name = "Abc", .Age = 25, .DOB_day = 1, .DOB_month = 1, .DOB_year = 2000, .gender = Male, .educational_status = Student}, .LoginCredentials_Form = {.LoginCredentials = {.User_Name = "UserNL3", .Password = "GoodPass123"}, .Password_Recheck = "GoodPass123"} };
static struct User_Input_Type Test_Name_Len32 = { .PersonalInfo_Form = {.name = "Abcdefghijklmnopqrstuvwxyz123456", .Age = 25, .DOB_day = 1, .DOB_month = 1, .DOB_year = 2000, .gender = Male, .educational_status = Student}, .LoginCredentials_Form = {.LoginCredentials = {.User_Name = "UserNL32", .Password = "GoodPass123"}, .Password_Recheck = "GoodPass123"} };
// CORRECTED Initializer for Name Length 33 Test (String truncated to 31 chars + null)
static struct User_Input_Type Test_Name_Len33 = {
    .PersonalInfo_Form = {.name = "Abcdefghijklmnopqrstuvwxyz12345", .Age = 25, .DOB_day = 1, .DOB_month = 1, .DOB_year = 2000, .gender = Male, .educational_status = Student}, // String fits in char[32]
    .LoginCredentials_Form = {.LoginCredentials = {.User_Name = "UserNL33", .Password = "GoodPass123"}, .Password_Recheck = "GoodPass123"}
};

// --- Age Range Tests ---
static struct User_Input_Type Test_Age_Minus1 = { .PersonalInfo_Form = {.name = "Test AgeM1", .Age = -1, .DOB_day = 1, .DOB_month = 1, .DOB_year = 2000, .gender = Male, .educational_status = Student}, .LoginCredentials_Form = {.LoginCredentials = {.User_Name = "UserAM1", .Password = "GoodPass123"}, .Password_Recheck = "GoodPass123"} };
static struct User_Input_Type Test_Age_0 = { .PersonalInfo_Form = {.name = "Test Age0", .Age = 0, .DOB_day = 1, .DOB_month = 1, .DOB_year = 2024, .gender = Male, .educational_status = Student}, .LoginCredentials_Form = {.LoginCredentials = {.User_Name = "UserA0", .Password = "GoodPass123"}, .Password_Recheck = "GoodPass123"} };
static struct User_Input_Type Test_Age_100 = { .PersonalInfo_Form = {.name = "Test Age100", .Age = 100, .DOB_day = 1, .DOB_month = 1, .DOB_year = 1925, .gender = Male, .educational_status = Student}, .LoginCredentials_Form = {.LoginCredentials = {.User_Name = "UserA100", .Password = "GoodPass123"}, .Password_Recheck = "GoodPass123"} };
static struct User_Input_Type Test_Age_101 = { .PersonalInfo_Form = {.name = "Test Age101", .Age = 101, .DOB_day = 1, .DOB_month = 1, .DOB_year = 1924, .gender = Male, .educational_status = Student}, .LoginCredentials_Form = {.LoginCredentials = {.User_Name = "UserA101", .Password = "GoodPass123"}, .Password_Recheck = "GoodPass123"} };

// --- Age/DOB Consistency Tests (Assuming CURRENT_YEAR = 2025)---
static struct User_Input_Type Test_Age_InconsistentFuture = { .PersonalInfo_Form = {.name = "Age InconsistentFuture", .Age = 25, .DOB_day = 1, .DOB_month = 1, .DOB_year = 2001, .gender = Male, .educational_status = Student}, .LoginCredentials_Form = {.LoginCredentials = {.User_Name = "UserAICF", .Password = "GoodPass123"}, .Password_Recheck = "GoodPass123"} };
static struct User_Input_Type Test_Age_InconsistentPast = { .PersonalInfo_Form = {.name = "Age InconsistentPast", .Age = 25, .DOB_day = 1, .DOB_month = 1, .DOB_year = 1998, .gender = Male, .educational_status = Student}, .LoginCredentials_Form = {.LoginCredentials = {.User_Name = "UserAICP", .Password = "GoodPass123"}, .Password_Recheck = "GoodPass123"} };

// --- DOB Day Consistency Tests ---
static struct User_Input_Type Test_DOB_Feb29_Leap_OkAge = { .PersonalInfo_Form = {.name = "Test LeapOk", .Age = 1, .DOB_day = 29, .DOB_month = 2, .DOB_year = 2024, .gender = Female, .educational_status = Graduate}, .LoginCredentials_Form = {.LoginCredentials = {.User_Name = "UserLeapOk", .Password = "GoodPass123"}, .Password_Recheck = "GoodPass123"} };
static struct User_Input_Type Test_DOB_Feb29_NonLeap = { .PersonalInfo_Form = {.name = "Test NonLeap", .Age = 0, .DOB_day = 29, .DOB_month = 2, .DOB_year = 2025, .gender = Female, .educational_status = Graduate}, .LoginCredentials_Form = {.LoginCredentials = {.User_Name = "UserNonLeap", .Password = "GoodPass123"}, .Password_Recheck = "GoodPass123"} };
static struct User_Input_Type Test_DOB_Apr31 = { .PersonalInfo_Form = {.name = "Test Apr31", .Age = 25, .DOB_day = 31, .DOB_month = 4, .DOB_year = 2000, .gender = Female, .educational_status = Graduate}, .LoginCredentials_Form = {.LoginCredentials = {.User_Name = "UserApr31", .Password = "GoodPass123"}, .Password_Recheck = "GoodPass123"} };

// --- DOB Day/Month/Year Range Tests ---
static struct User_Input_Type Test_DOB_Day0 = { .PersonalInfo_Form = {.name = "Test Day0", .Age = 25, .DOB_day = 0, .DOB_month = 1, .DOB_year = 2000, .gender = Male, .educational_status = Student}, .LoginCredentials_Form = {.LoginCredentials = {.User_Name = "UserDay0", .Password = "GoodPass123"}, .Password_Recheck = "GoodPass123"} };
static struct User_Input_Type Test_DOB_Month0 = { .PersonalInfo_Form = {.name = "Test Month0", .Age = 25, .DOB_day = 1, .DOB_month = 0, .DOB_year = 2000, .gender = Male, .educational_status = Student}, .LoginCredentials_Form = {.LoginCredentials = {.User_Name = "UserMonth0", .Password = "GoodPass123"}, .Password_Recheck = "GoodPass123"} };
static struct User_Input_Type Test_DOB_Month13 = { .PersonalInfo_Form = {.name = "Test Month13", .Age = 25, .DOB_day = 1, .DOB_month = 13, .DOB_year = 2000, .gender = Male, .educational_status = Student}, .LoginCredentials_Form = {.LoginCredentials = {.User_Name = "UserMonth13", .Password = "GoodPass123"}, .Password_Recheck = "GoodPass123"} };
static struct User_Input_Type Test_DOB_Year1923 = { .PersonalInfo_Form = {.name = "Test Year1923", .Age = 101, .DOB_day = 1, .DOB_month = 1, .DOB_year = 1923, .gender = Male, .educational_status = Student}, .LoginCredentials_Form = {.LoginCredentials = {.User_Name = "UserY1923", .Password = "GoodPass123"}, .Password_Recheck = "GoodPass123"} };
static struct User_Input_Type Test_DOB_Year2025 = { .PersonalInfo_Form = {.name = "Test Year2025", .Age = 0, .DOB_day = 1, .DOB_month = 1, .DOB_year = 2025, .gender = Male, .educational_status = Student}, .LoginCredentials_Form = {.LoginCredentials = {.User_Name = "UserY2025", .Password = "GoodPass123"}, .Password_Recheck = "GoodPass123"} };

// --- Enum Tests ---
static struct User_Input_Type Test_InvalidEdu = { .PersonalInfo_Form = {.name = "Test InvalidEdu", .Age = 25, .DOB_day = 1, .DOB_month = 1, .DOB_year = 2000, .gender = Male, .educational_status = (enum Educational_Status)-1}, .LoginCredentials_Form = {.LoginCredentials = {.User_Name = "UserInvEdu", .Password = "GoodPass123"}, .Password_Recheck = "GoodPass123"} };
static struct User_Input_Type Test_InvalidGender = { .PersonalInfo_Form = {.name = "Test InvalidGender", .Age = 25, .DOB_day = 1, .DOB_month = 1, .DOB_year = 2000, .gender = (enum Gender)-1, .educational_status = Student}, .LoginCredentials_Form = {.LoginCredentials = {.User_Name = "UserInvGen", .Password = "GoodPass123"}, .Password_Recheck = "GoodPass123"} };

// --- Username Length Tests ---
static struct User_Input_Type Test_User_Len7 = { .PersonalInfo_Form = {.name = "Test UserLen7", .Age = 25, .DOB_day = 1, .DOB_month = 1, .DOB_year = 2000, .gender = Male, .educational_status = Student}, .LoginCredentials_Form = {.LoginCredentials = {.User_Name = "UserL7", .Password = "GoodPass123"}, .Password_Recheck = "GoodPass123"} };
static struct User_Input_Type Test_User_Len8 = { .PersonalInfo_Form = {.name = "Test UserLen8", .Age = 25, .DOB_day = 1, .DOB_month = 1, .DOB_year = 2000, .gender = Male, .educational_status = Student}, .LoginCredentials_Form = {.LoginCredentials = {.User_Name = "UserLen8", .Password = "GoodPass123"}, .Password_Recheck = "GoodPass123"} };
static struct User_Input_Type Test_User_Len32 = { .PersonalInfo_Form = {.name = "Test UserLen32", .Age = 25, .DOB_day = 1, .DOB_month = 1, .DOB_year = 2000, .gender = Male, .educational_status = Student}, .LoginCredentials_Form = {.LoginCredentials = {.User_Name = "Usernamethirtytwocharslong123456", .Password = "GoodPass123"}, .Password_Recheck = "GoodPass123"} };
// CORRECTED Initializer for Username Length 33 Test (String truncated to 31 chars + null)
static struct User_Input_Type Test_User_Len33 = {
    .PersonalInfo_Form = {.name = "Test UserLen33", .Age = 25, .DOB_day = 1, .DOB_month = 1, .DOB_year = 2000, .gender = Male, .educational_status = Student},
    .LoginCredentials_Form = {.LoginCredentials = {.User_Name = "Usernamethirtyonecharslong12345", .Password = "GoodPass123"}, .Password_Recheck = "GoodPass123"} // String fits in char[32]
};

// --- Password Length Tests ---
static struct User_Input_Type Test_Pass_Len7 = { .PersonalInfo_Form = {.name = "Test PassLen7", .Age = 25, .DOB_day = 1, .DOB_month = 1, .DOB_year = 2000, .gender = Male, .educational_status = Student}, .LoginCredentials_Form = {.LoginCredentials = {.User_Name = "UserPassL7", .Password = "PassL7"}, .Password_Recheck = "PassL7"} };
static struct User_Input_Type Test_Pass_Len8 = { .PersonalInfo_Form = {.name = "Test PassLen8", .Age = 25, .DOB_day = 1, .DOB_month = 1, .DOB_year = 2000, .gender = Male, .educational_status = Student}, .LoginCredentials_Form = {.LoginCredentials = {.User_Name = "UserPassL8", .Password = "PassLen8"}, .Password_Recheck = "PassLen8"} };
static struct User_Input_Type Test_Pass_Len32 = { .PersonalInfo_Form = {.name = "Test PassLen32", .Age = 25, .DOB_day = 1, .DOB_month = 1, .DOB_year = 2000, .gender = Male, .educational_status = Student}, .LoginCredentials_Form = {.LoginCredentials = {.User_Name = "UserPassL32", .Password = "Passwordthirtytwocharslong123456"}, .Password_Recheck = "Passwordthirtytwocharslong123456"} };
// CORRECTED Initializer for Password Length 33 Test (Strings truncated to 31 chars + null)
static struct User_Input_Type Test_Pass_Len33 = {
    .PersonalInfo_Form = {.name = "Test PassLen33", .Age = 25, .DOB_day = 1, .DOB_month = 1, .DOB_year = 2000, .gender = Male, .educational_status = Student},
    .LoginCredentials_Form = {.LoginCredentials = {.User_Name = "UserPassL33", .Password = "Passwordthirtyonecharslong12345"}, .Password_Recheck = "Passwordthirtyonecharslong12345"} // Strings fit in char[32]
};


// ==========================================================
// Test Case Functions (Comments included as requested)
// ==========================================================

/************************************************************************************
* Test ID             : TestCase_ValidData_Raw
* Description         : Testing Add Account Functionality with a completely valid set of inputs.
* Pre-requisits       : Database initialized. Assumes username "EdgesAcademyUser" doesn't exist.
* Test inputs         :
* Name                 -> "Ahmed Tarek" (len 11)
* Age                  -> 26
* DOB                  -> 23/10/1998
* Gender               -> Male
* Educational_Status   -> Masters_Student
* UserName             -> "EdgesAcademyUser" (len 16)
* Password             -> "EdgesPass123" (len 12)
* Password Recheck     -> "EdgesPass123" (len 12, matches)
* Test Expected output: Add_Account function should return TRUE.
* Reason              : All inputs meet the validation criteria.
*************************************************************************************/
static void TestCase_ValidData_Raw(void) {
    unsigned char result = Add_Account(&Test1_User_Valid);
    CU_ASSERT_EQUAL(result, TRUE);
    if (result == TRUE) {
        Delete_Account(current_user_test - 1); // Adjust if ID tracking is different
    }
}

/************************************************************************************
* Test ID             : TestCase_NameLen2
* Description         : Testing Add Account Functionality with Name length less than minimum (3).
* Pre-requisits       : Database initialized.
* Test inputs         :
* Name                 -> "Ab" (len 2)
* Other inputs valid.
* Test Expected output: Add_Account function should return FALSE.
* Reason              : Name length is less than the minimum required (3).
*************************************************************************************/
static void TestCase_NameLen2(void) { CU_ASSERT_EQUAL(Add_Account(&Test_Name_Len2), FALSE); }

/************************************************************************************
* Test ID             : TestCase_NameLen3
* Description         : Testing Add Account Functionality with Name length equal to minimum (3).
* Pre-requisits       : Database initialized. Assumes username "UserNL3" doesn't exist.
* Test inputs         :
* Name                 -> "Abc" (len 3)
* Other inputs valid.
* Test Expected output: Add_Account function should return TRUE.
* Reason              : Name length meets the minimum requirement (3).
*************************************************************************************/
static void TestCase_NameLen3(void) {
    unsigned char result = Add_Account(&Test_Name_Len3);
    CU_ASSERT_EQUAL(result, TRUE);
    if (result == TRUE) Delete_Account(current_user_test - 1); // Cleanup
}

/************************************************************************************
* Test ID             : TestCase_NameLen32
* Description         : Testing Add Account Functionality with Name length equal to maximum (32).
* Pre-requisits       : Database initialized. Assumes username "UserNL32" doesn't exist.
* Test inputs         :
* Name                 -> "Abcdefghijklmnopqrstuvwxyz123456" (len 32)
* Other inputs valid.
* Test Expected output: Add_Account function should return TRUE.
* Reason              : Name length meets the maximum requirement (32).
*************************************************************************************/
static void TestCase_NameLen32(void) {
    unsigned char result = Add_Account(&Test_Name_Len32);
    CU_ASSERT_EQUAL(result, TRUE);
    if (result == TRUE) Delete_Account(current_user_test - 1); // Cleanup
}

/************************************************************************************
* Test ID             : TestCase_NameLen33
* Description         : Testing Add Account Functionality with Name length considered > 32 by strlen.
* Pre-requisits       : Database initialized.
* Test inputs         :
* Name                 -> "Abcdefghijklmnopqrstuvwxyz12345" (len 31, fits buffer)
* (Test relies on Add_Account strlen check logic for > 32)
* Other inputs valid.
* Test Expected output: Add_Account function should return FALSE.
* Reason              : Name length (tested via strlen in Add_Account) should exceed the maximum allowed (32).
*************************************************************************************/
static void TestCase_NameLen33(void) { CU_ASSERT_EQUAL(Add_Account(&Test_Name_Len33), FALSE); } // Test relies on Add_Account checking strlen

/************************************************************************************
* Test ID             : TestCase_AgeMinus1
* Description         : Testing Add Account Functionality with Age less than minimum (0).
* Pre-requisits       : Database initialized.
* Test inputs         :
* Age                  -> -1
* Other inputs valid.
* Test Expected output: Add_Account function should return FALSE.
* Reason              : Age is less than the minimum allowed (0).
*************************************************************************************/
static void TestCase_AgeMinus1(void) { CU_ASSERT_EQUAL(Add_Account(&Test_Age_Minus1), FALSE); }

/************************************************************************************
* Test ID             : TestCase_Age0
* Description         : Testing Add Account Functionality with Age equal to minimum (0).
* Pre-requisits       : Database initialized. Assumes username "UserA0" doesn't exist.
* Test inputs         :
* Age                  -> 0
* DOB Year             -> 2024 (Consistent with Age 0 for CURRENT_YEAR 2025)
* Other inputs valid.
* Test Expected output: Add_Account function should return TRUE.
* Reason              : Age meets the minimum requirement (0) and DOB is consistent.
*************************************************************************************/
static void TestCase_Age0(void) {
    unsigned char result = Add_Account(&Test_Age_0);
    CU_ASSERT_EQUAL(result, TRUE);
    if (result == TRUE) Delete_Account(current_user_test - 1); // Cleanup
}

/************************************************************************************
* Test ID             : TestCase_Age100
* Description         : Testing Add Account Functionality with Age equal to maximum (100).
* Pre-requisits       : Database initialized. Assumes username "UserA100" doesn't exist.
* Test inputs         :
* Age                  -> 100
* DOB Year             -> 1925 (Consistent with Age 100 for CURRENT_YEAR 2025)
* Other inputs valid.
* Test Expected output: Add_Account function should return TRUE.
* Reason              : Age meets the maximum requirement (100) and DOB is consistent.
*************************************************************************************/
static void TestCase_Age100(void) {
    unsigned char result = Add_Account(&Test_Age_100);
    CU_ASSERT_EQUAL(result, TRUE);
    if (result == TRUE) Delete_Account(current_user_test - 1); // Cleanup
}

/************************************************************************************
* Test ID             : TestCase_Age101
* Description         : Testing Add Account Functionality with Age greater than maximum (100).
* Pre-requisits       : Database initialized.
* Test inputs         :
* Age                  -> 101
* Other inputs valid.
* Test Expected output: Add_Account function should return FALSE.
* Reason              : Age exceeds the maximum allowed (100).
*************************************************************************************/
static void TestCase_Age101(void) { CU_ASSERT_EQUAL(Add_Account(&Test_Age_101), FALSE); }

/************************************************************************************
* Test ID             : TestCase_AgeInconsistentFuture
* Description         : Testing Add Account Functionality where DOB Year implies an age younger than stated Age.
* Pre-requisits       : Database initialized.
* Test inputs         :
* Age                  -> 25
* DOB Year             -> 2001 (Implies Age 24 if CURRENT_YEAR is 2025)
* Other inputs valid.
* Test Expected output: Add_Account function should return FALSE.
* Reason              : Age (25) is inconsistent with calculated age from DOB (24).
*************************************************************************************/
static void TestCase_AgeInconsistentFuture(void) { CU_ASSERT_EQUAL(Add_Account(&Test_Age_InconsistentFuture), FALSE); }

/************************************************************************************
* Test ID             : TestCase_AgeInconsistentPast
* Description         : Testing Add Account Functionality where DOB Year implies an age older than stated Age + 1.
* Pre-requisits       : Database initialized.
* Test inputs         :
* Age                  -> 25
* DOB Year             -> 1998 (Implies Age 27 if CURRENT_YEAR is 2025)
* Other inputs valid.
* Test Expected output: Add_Account function should return FALSE.
* Reason              : Age (25) is inconsistent with calculated age from DOB (27).
*************************************************************************************/
static void TestCase_AgeInconsistentPast(void) { CU_ASSERT_EQUAL(Add_Account(&Test_Age_InconsistentPast), FALSE); }

/************************************************************************************
* Test ID             : TestCase_DOBFeb29_LeapOkAge
* Description         : Testing Add Account Functionality with valid leap day (Feb 29) in a leap year.
* Pre-requisits       : Database initialized. Assumes username "UserLeapOk" doesn't exist.
* Test inputs         :
* DOB                  -> 29/02/2024
* Age                  -> 1 (Consistent for CURRENT_YEAR 2025)
* Other inputs valid.
* Test Expected output: Add_Account function should return TRUE.
* Reason              : Valid leap day in a leap year, Age consistent.
*************************************************************************************/
static void TestCase_DOBFeb29_LeapOkAge(void) {
    unsigned char result = Add_Account(&Test_DOB_Feb29_Leap_OkAge);
    CU_ASSERT_EQUAL(result, TRUE);
    if (result == TRUE) Delete_Account(current_user_test - 1); // Cleanup
}

/************************************************************************************
* Test ID             : TestCase_DOBFeb29_NonLeap
* Description         : Testing Add Account Functionality with Feb 29 in a non-leap year.
* Pre-requisits       : Database initialized.
* Test inputs         :
* DOB                  -> 29/02/2025
* Age                  -> 0 (Consistent for CURRENT_YEAR 2025)
* Other inputs valid.
* Test Expected output: Add_Account function should return FALSE.
* Reason              : Invalid day (29) for February in a non-leap year (2025). Check uses Get_Number_OfDays.
*************************************************************************************/
static void TestCase_DOBFeb29_NonLeap(void) { CU_ASSERT_EQUAL(Add_Account(&Test_DOB_Feb29_NonLeap), FALSE); }

/************************************************************************************
* Test ID             : TestCase_DOBApr31
* Description         : Testing Add Account Functionality with day 31 for a month with only 30 days (April).
* Pre-requisits       : Database initialized.
* Test inputs         :
* DOB                  -> 31/04/2000
* Age                  -> 25 (Consistent for CURRENT_YEAR 2025)
* Other inputs valid.
* Test Expected output: Add_Account function should return FALSE.
* Reason              : Invalid day (31) for April. Check uses Get_Number_OfDays.
*************************************************************************************/
static void TestCase_DOBApr31(void) { CU_ASSERT_EQUAL(Add_Account(&Test_DOB_Apr31), FALSE); }

/************************************************************************************
* Test ID             : TestCase_DOBDay0
* Description         : Testing Add Account Functionality with DOB day less than minimum (1).
* Pre-requisits       : Database initialized.
* Test inputs         :
* DOB Day              -> 0
* Other inputs valid.
* Test Expected output: Add_Account function should return FALSE.
* Reason              : DOB Day is less than the minimum allowed (1). Explicit check DOB_day < 1.
*************************************************************************************/
static void TestCase_DOBDay0(void) { CU_ASSERT_EQUAL(Add_Account(&Test_DOB_Day0), FALSE); }

/************************************************************************************
* Test ID             : TestCase_DOBMonth0
* Description         : Testing Add Account Functionality with DOB month less than minimum (1).
* Pre-requisits       : Database initialized.
* Test inputs         :
* DOB Month            -> 0
* Other inputs valid.
* Test Expected output: Add_Account function should return FALSE.
* Reason              : DOB Month is less than the minimum allowed (1). Explicit check DOB_month < 1. Also fails Get_Number_OfDays.
*************************************************************************************/
static void TestCase_DOBMonth0(void) { CU_ASSERT_EQUAL(Add_Account(&Test_DOB_Month0), FALSE); }

/************************************************************************************
* Test ID             : TestCase_DOBMonth13
* Description         : Testing Add Account Functionality with DOB month greater than maximum (12).
* Pre-requisits       : Database initialized.
* Test inputs         :
* DOB Month            -> 13
* Other inputs valid.
* Test Expected output: Add_Account function should return FALSE.
* Reason              : DOB Month exceeds the maximum allowed (12). Explicit check DOB_month > 12. Also fails Get_Number_OfDays.
*************************************************************************************/
static void TestCase_DOBMonth13(void) { CU_ASSERT_EQUAL(Add_Account(&Test_DOB_Month13), FALSE); }

/************************************************************************************
* Test ID             : TestCase_DOBYear1923
* Description         : Testing Add Account Functionality with DOB year less than minimum (1924).
* Pre-requisits       : Database initialized.
* Test inputs         :
* DOB Year             -> 1923
* Age                  -> 101 (Consistent for CURRENT_YEAR 2025)
* Other inputs valid.
* Test Expected output: Add_Account function should return FALSE.
* Reason              : DOB Year is less than the minimum allowed (1924). Explicit check DOB_year < 1924.
*************************************************************************************/
static void TestCase_DOBYear1923(void) { CU_ASSERT_EQUAL(Add_Account(&Test_DOB_Year1923), FALSE); }

/************************************************************************************
* Test ID             : TestCase_DOBYear2025
* Description         : Testing Add Account Functionality with DOB year greater than maximum (2024).
* Pre-requisits       : Database initialized.
* Test inputs         :
* DOB Year             -> 2025
* Age                  -> 0 (Consistent for CURRENT_YEAR 2025)
* Other inputs valid.
* Test Expected output: Add_Account function should return FALSE.
* Reason              : DOB Year exceeds the maximum allowed (2024). Explicit check DOB_year > 2024.
*************************************************************************************/
static void TestCase_DOBYear2025(void) { CU_ASSERT_EQUAL(Add_Account(&Test_DOB_Year2025), FALSE); }

/************************************************************************************
* Test ID             : TestCase_InvalidEdu
* Description         : Testing Add Account Functionality with an invalid educational status enum value.
* Pre-requisits       : Database initialized.
* Test inputs         :
* Educational_Status   -> -1 (cast to enum type)
* Other inputs valid.
* Test Expected output: Add_Account function should return FALSE.
* Reason              : Educational status enum value is not one of the explicitly allowed values.
*************************************************************************************/
static void TestCase_InvalidEdu(void) { CU_ASSERT_EQUAL(Add_Account(&Test_InvalidEdu), FALSE); }

/************************************************************************************
* Test ID             : TestCase_InvalidGender
* Description         : Testing Add Account Functionality with an invalid gender enum value.
* Pre-requisits       : Database initialized.
* Test inputs         :
* Gender               -> -1 (cast to enum type)
* Other inputs valid.
* Test Expected output: Add_Account function should return FALSE.
* Reason              : Gender enum value is not Male or Female.
*************************************************************************************/
static void TestCase_InvalidGender(void) { CU_ASSERT_EQUAL(Add_Account(&Test_InvalidGender), FALSE); }

/************************************************************************************
* Test ID             : TestCase_UserLen7
* Description         : Testing Add Account Functionality with Username length less than minimum (8).
* Pre-requisits       : Database initialized.
* Test inputs         :
* UserName             -> "UserL7" (len 7)
* Other inputs valid.
* Test Expected output: Add_Account function should return FALSE.
* Reason              : Username length is less than the minimum required (8).
*************************************************************************************/
static void TestCase_UserLen7(void) { CU_ASSERT_EQUAL(Add_Account(&Test_User_Len7), FALSE); }

/************************************************************************************
* Test ID             : TestCase_UserLen8
* Description         : Testing Add Account Functionality with Username length equal to minimum (8).
* Pre-requisits       : Database initialized. Assumes username "UserLen8" doesn't exist.
* Test inputs         :
* UserName             -> "UserLen8" (len 8)
* Other inputs valid.
* Test Expected output: Add_Account function should return TRUE.
* Reason              : Username length meets the minimum requirement (8).
*************************************************************************************/
static void TestCase_UserLen8(void) {
    unsigned char result = Add_Account(&Test_User_Len8);
    CU_ASSERT_EQUAL(result, TRUE);
    if (result == TRUE) Delete_Account(current_user_test - 1); // Cleanup
}

/************************************************************************************
* Test ID             : TestCase_UserLen32
* Description         : Testing Add Account Functionality with Username length equal to maximum (32).
* Pre-requisits       : Database initialized. Assumes username "Usernamethirtytwocharslong123456" doesn't exist.
* Test inputs         :
* UserName             -> "Usernamethirtytwocharslong123456" (len 32)
* Other inputs valid.
* Test Expected output: Add_Account function should return TRUE.
* Reason              : Username length meets the maximum requirement (32).
*************************************************************************************/
static void TestCase_UserLen32(void) {
    unsigned char result = Add_Account(&Test_User_Len32);
    CU_ASSERT_EQUAL(result, TRUE);
    if (result == TRUE) Delete_Account(current_user_test - 1); // Cleanup
}

/************************************************************************************
* Test ID             : TestCase_UserLen33
* Description         : Testing Add Account Functionality with Username length considered > 32 by strlen.
* Pre-requisits       : Database initialized.
* Test inputs         :
* UserName             -> "Usernamethirtyonecharslong12345" (len 31, fits buffer)
* (Test relies on Add_Account strlen check logic for > 32)
* Other inputs valid.
* Test Expected output: Add_Account function should return FALSE.
* Reason              : Username length (tested via strlen in Add_Account) should exceed the maximum allowed (32).
*************************************************************************************/
static void TestCase_UserLen33(void) { CU_ASSERT_EQUAL(Add_Account(&Test_User_Len33), FALSE); } // Test relies on Add_Account checking strlen

/************************************************************************************
* Test ID             : TestCase_PassLen7
* Description         : Testing Add Account Functionality with Password length less than minimum (8).
* Pre-requisits       : Database initialized.
* Test inputs         :
* Password             -> "PassL7" (len 7)
* Password Recheck     -> "PassL7" (len 7, matches)
* Other inputs valid.
* Test Expected output: Add_Account function should return FALSE.
* Reason              : Password length is less than the minimum required (8). Checks both password and recheck lengths.
*************************************************************************************/
static void TestCase_PassLen7(void) { CU_ASSERT_EQUAL(Add_Account(&Test_Pass_Len7), FALSE); }

/************************************************************************************
* Test ID             : TestCase_PassLen8
* Description         : Testing Add Account Functionality with Password length equal to minimum (8).
* Pre-requisits       : Database initialized. Assumes username "UserPassL8" doesn't exist.
* Test inputs         :
* Password             -> "PassLen8" (len 8)
* Password Recheck     -> "PassLen8" (len 8, matches)
* Other inputs valid.
* Test Expected output: Add_Account function should return TRUE.
* Reason              : Password length meets the minimum requirement (8).
*************************************************************************************/
static void TestCase_PassLen8(void) {
    unsigned char result = Add_Account(&Test_Pass_Len8);
    CU_ASSERT_EQUAL(result, TRUE);
    if (result == TRUE) Delete_Account(current_user_test - 1); // Cleanup
}

/************************************************************************************
* Test ID             : TestCase_PassLen32
* Description         : Testing Add Account Functionality with Password length equal to maximum (32).
* Pre-requisits       : Database initialized. Assumes username "UserPassL32" doesn't exist.
* Test inputs         :
* Password             -> "Passwordthirtytwocharslong123456" (len 32)
* Password Recheck     -> "Passwordthirtytwocharslong123456" (len 32, matches)
* Other inputs valid.
* Test Expected output: Add_Account function should return TRUE.
* Reason              : Password length meets the maximum requirement (32).
*************************************************************************************/
static void TestCase_PassLen32(void) {
    unsigned char result = Add_Account(&Test_Pass_Len32);
    CU_ASSERT_EQUAL(result, TRUE);
    if (result == TRUE) Delete_Account(current_user_test - 1); // Cleanup
}

/************************************************************************************
* Test ID             : TestCase_PassLen33
* Description         : Testing Add Account Functionality with Password length considered > 32 by strlen.
* Pre-requisits       : Database initialized.
* Test inputs         :
* Password             -> "Passwordthirtyonecharslong12345" (len 31, fits buffer)
* Password Recheck     -> "Passwordthirtyonecharslong12345" (len 31, fits buffer)
* (Test relies on Add_Account strlen check logic for > 32)
* Other inputs valid.
* Test Expected output: Add_Account function should return FALSE.
* Reason              : Password length (tested via strlen in Add_Account) should exceed the maximum allowed (32).
*************************************************************************************/
static void TestCase_PassLen33(void) { CU_ASSERT_EQUAL(Add_Account(&Test_Pass_Len33), FALSE); } // Test relies on Add_Account checking strlen

/************************************************************************************
* Test ID             : TestCase_PassMismatch
* Description         : Testing Add Account Functionality with mismatching Password and Password Recheck fields.
* Pre-requisits       : Database initialized.
* Test inputs         :
* Password             -> "ValidPassword1" (len 14)
* Password Recheck     -> "DifferentPass2" (len 14, mismatch)
* Other inputs valid (Rania Hesham user data).
* Test Expected output: Add_Account function should return FALSE.
* Reason              : Password and Password Recheck inputs do not match (strcmp != 0).
*************************************************************************************/
static void TestCase_PassMismatch(void) {
    CU_ASSERT_EQUAL(Add_Account(&Test2_User_MismatchPass), FALSE);
}


// --- Suite Setup/Cleanup for Duplicate Test ---
static int setup_DuplicateTest_Suite(void) {
    unsigned char result = Add_Account(&Test1_User_Valid); // Adds user "EdgesAcademyUser"
    return (result == TRUE) ? 0 : -1; // CUnit convention: 0 for success
}

static int teardown_DuplicateTest_Suite(void) {
    // Delete the user added in setup ("EdgesAcademyUser").
    // ASSUMES Delete_Account uses the ID from the global 'current_user_test' which was updated by Add_Account in setup.
    unsigned char result = Delete_Account(current_user_test - 1);
    return (result == TRUE) ? 0 : -1;
}

/************************************************************************************
* Test ID             : TestCase_DuplicateUsername
* Description         : Testing Add Account Functionality attempting to add a user with an existing username.
* Pre-requisits       : User "EdgesAcademyUser" added via suite setup (setup_DuplicateTest_Suite).
* Test inputs         :
* UserName             -> "EdgesAcademyUser" (same as existing user)
* Other inputs valid (using Test_User_Len8 data as base).
* Test Expected output: Add_Account function should return FALSE (assuming DBM_Add_User handles duplicates).
* Reason              : Username already exists. Add_Account calls DBM_Add_User, which should fail/prevent duplicate.
*************************************************************************************/
static void TestCase_DuplicateUsername(void) {
    struct User_Input_Type duplicate_user_data = Test_User_Len8;
    strcpy(duplicate_user_data.PersonalInfo_Form.name, "Duplicate Test Name");
    strcpy(duplicate_user_data.LoginCredentials_Form.LoginCredentials.User_Name, "EdgesAcademyUser");

    // Assume DBM_Add_User prevents duplicate and Add_Account returns FALSE based on that.
    CU_ASSERT_EQUAL(Add_Account(&duplicate_user_data), FALSE);
}


// ==========================================================
// Main Test Runner Function
// ==========================================================

void Main_Test_Runner(void)
{
    CU_pSuite suite_valid = NULL;
    CU_pSuite suite_invalid = NULL;
    CU_pSuite suite_duplicate = NULL;

    /* initialize the CUnit test registry */
    if (CUE_SUCCESS != CU_initialize_registry())
        return;

    /* add suites to the registry */
    suite_valid = CU_add_suite("Add Account - Valid Cases (Self-Cleaning)", NULL, NULL);
    suite_invalid = CU_add_suite("Add Account - Invalid Cases", NULL, NULL);
    suite_duplicate = CU_add_suite("Add Account - Duplicate Username Check", setup_DuplicateTest_Suite, teardown_DuplicateTest_Suite);

    if (NULL == suite_valid || NULL == suite_invalid || NULL == suite_duplicate) {
        CU_cleanup_registry();
        return;
    }

    /* add the tests to the suites */

    // --- Valid Suite ---
    if ((NULL == CU_add_test(suite_valid, "Test Valid Data Add/Delete", TestCase_ValidData_Raw)) ||
        (NULL == CU_add_test(suite_valid, "Name Length 3 Add/Delete", TestCase_NameLen3)) ||
        (NULL == CU_add_test(suite_valid, "Name Length 32 Add/Delete", TestCase_NameLen32)) ||
        (NULL == CU_add_test(suite_valid, "Age 0 Add/Delete", TestCase_Age0)) ||
        (NULL == CU_add_test(suite_valid, "Age 100 Add/Delete", TestCase_Age100)) ||
        (NULL == CU_add_test(suite_valid, "DOB Feb 29 Leap Year Add/Delete", TestCase_DOBFeb29_LeapOkAge)) ||
        (NULL == CU_add_test(suite_valid, "Username Length 8 Add/Delete", TestCase_UserLen8)) ||
        (NULL == CU_add_test(suite_valid, "Username Length 32 Add/Delete", TestCase_UserLen32)) ||
        (NULL == CU_add_test(suite_valid, "Password Length 8 Add/Delete", TestCase_PassLen8)) ||
        (NULL == CU_add_test(suite_valid, "Password Length 32 Add/Delete", TestCase_PassLen32)))
    {
        CU_cleanup_registry();
        return;
    }

    // --- Invalid Suite ---
    if ((NULL == CU_add_test(suite_invalid, "Name Length 2", TestCase_NameLen2)) ||
        (NULL == CU_add_test(suite_invalid, "Name Length > 32 Check", TestCase_NameLen33)) || // Renamed for clarity
        (NULL == CU_add_test(suite_invalid, "Age -1", TestCase_AgeMinus1)) ||
        (NULL == CU_add_test(suite_invalid, "Age 101", TestCase_Age101)) ||
        (NULL == CU_add_test(suite_invalid, "Age Inconsistent Future DOB", TestCase_AgeInconsistentFuture)) ||
        (NULL == CU_add_test(suite_invalid, "Age Inconsistent Past DOB", TestCase_AgeInconsistentPast)) ||
        (NULL == CU_add_test(suite_invalid, "DOB Feb 29 Non-Leap", TestCase_DOBFeb29_NonLeap)) ||
        (NULL == CU_add_test(suite_invalid, "DOB Apr 31", TestCase_DOBApr31)) ||
        (NULL == CU_add_test(suite_invalid, "DOB Day 0", TestCase_DOBDay0)) ||
        (NULL == CU_add_test(suite_invalid, "DOB Month 0", TestCase_DOBMonth0)) ||
        (NULL == CU_add_test(suite_invalid, "DOB Month 13", TestCase_DOBMonth13)) ||
        (NULL == CU_add_test(suite_invalid, "DOB Year 1923", TestCase_DOBYear1923)) ||
        (NULL == CU_add_test(suite_invalid, "DOB Year 2025", TestCase_DOBYear2025)) ||
        (NULL == CU_add_test(suite_invalid, "Invalid Educational Status", TestCase_InvalidEdu)) ||
        (NULL == CU_add_test(suite_invalid, "Invalid Gender", TestCase_InvalidGender)) ||
        (NULL == CU_add_test(suite_invalid, "Username Length 7", TestCase_UserLen7)) ||
        (NULL == CU_add_test(suite_invalid, "Username Length > 32 Check", TestCase_UserLen33)) || // Renamed for clarity
        (NULL == CU_add_test(suite_invalid, "Password Length 7", TestCase_PassLen7)) ||
        (NULL == CU_add_test(suite_invalid, "Password Length > 32 Check", TestCase_PassLen33)) || // Renamed for clarity
        (NULL == CU_add_test(suite_invalid, "Password Mismatch", TestCase_PassMismatch)))
    {
        CU_cleanup_registry();
        return;
    }

    // --- Duplicate Check Suite ---
    if ((NULL == CU_add_test(suite_duplicate, "Attempt Duplicate Username", TestCase_DuplicateUsername)))
    {
        CU_cleanup_registry();
        return;
    }


    /* Run all tests using the CUnit Basic interface */
    printf("Running Add_Account Tests...\n");
    CU_basic_set_mode(CU_BRM_VERBOSE);
    CU_basic_run_tests();
    printf("\nAdd_Account Tests Complete.\n");
    // Optional: Show summary programmatically if desired
    // printf("Summary: Ran %d tests. Failures: %d\n", CU_get_number_of_tests_run(), CU_get_number_of_failures());
    // CU_basic_show_failures(CU_get_failure_list());

    /* Clean up registry and return */
    CU_cleanup_registry();
    // return CU_get_error(); // Optional: return CUnit error code
}