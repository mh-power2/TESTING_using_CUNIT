#pragma once

#include "../DB/DB_Manager.h"
#include "../CreateAccount/Create_Account.h"
#include "../Login/Login.h"
/* Prototype Function to Start The Application */
unsigned char Main_App_Runner();
