#pragma once

/* The Hash password for the Admin Login */
#define SECRET_ADMIN_TOKEN 10203040
